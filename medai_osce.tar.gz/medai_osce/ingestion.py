"""Media ingestion utilities for the simplified OSCE pipeline.

This module contains functions to extract audio from video files and to
sample image frames at a fixed interval.  It intentionally avoids
pulling in heavy external services; instead it relies on `ffmpeg` via
the `ffmpeg-python` wrapper.  You must have the `ffmpeg` binary
installed on your system.

Example usage:

```python
from medai_osce.ingestion import extract_audio, sample_frames

# Extract a mono 16 kHz WAV file from a camera video
audio_path = extract_audio(["/path/to/camA.mp4", "/path/to/camB.mp4"],
                           out_dir="/tmp")

# Sample one frame per second for vision cues
frames = sample_frames("/path/to/camA.mp4", fps=1.0)
for i, img in enumerate(frames):
    img.save(f"/tmp/frame_{i:03d}.jpg")
```
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path
from typing import List, Sequence

import ffmpeg  # type: ignore
from PIL import Image
import numpy as np

def extract_audio(video_paths: Sequence[str], out_dir: str | None = None) -> Path:
    """Extract a mono 16 kHz WAV file from the first available video.

    Parameters
    ----------
    video_paths:
        A sequence of video file paths.  The first path that exists on
        disk will be used for audio extraction.  If a separate room
        microphone recording is available (e.g. `room_audio.wav`), you
        should pass it as the only element in `video_paths`.
    out_dir:
        Directory where the extracted WAV file will be written.  If
        ``None``, a temporary directory is created.

    Returns
    -------
    Path
        The path to the extracted WAV file.

    Notes
    -----
    This function invokes `ffmpeg` with the following options:

    * `-ac 1` forces mono output.
    * `-ar 16000` sets the sample rate to 16 kHz.
    * `-f wav` specifies that the output is a WAV file.

    On errors the function will raise ``RuntimeError`` with the
    underlying stderr from ffmpeg.
    """
    if not video_paths:
        raise ValueError("video_paths must be non‑empty")
    src = None
    for vp in video_paths:
        p = Path(vp)
        if p.exists():
            src = p
            break
    if src is None:
        raise FileNotFoundError(f"None of the provided video paths exist: {video_paths}")

    out_dir = out_dir or tempfile.mkdtemp(prefix="medai_audio_")
    out_path = Path(out_dir) / (src.stem + ".wav")

    # Build the ffmpeg command
    try:
        (
            ffmpeg
            .input(str(src))
            .output(str(out_path), ac=1, ar=16000, format='wav')
            .run(quiet=True, overwrite_output=True)
        )
    except ffmpeg.Error as e:
        raise RuntimeError(f"ffmpeg failed: {e.stderr}") from e

    return out_path


def sample_frames(video_path: str, fps: float = 0.5, max_frames: int | None = None) -> List[Image.Image]:
    """Sample frames from a video at a given rate and return PIL Images.

    Parameters
    ----------
    video_path:
        Path to a video file from which to extract frames.
    fps:
        Number of frames per second to sample.  A value of 0.5 means one
        frame every two seconds.  The default of 0.5 yields a small
        number of frames for long videos and is suitable for scoring
        behavioural rubrics.
    max_frames:
        Optional cap on the total number of frames returned.  If set
        to ``None``, all sampled frames are returned.

    Returns
    -------
    List[Image.Image]
        A list of PIL Image objects in RGB mode.

    Notes
    -----
    This function uses ffmpeg to decode frames into raw RGB arrays and
    converts them into PIL Images.  It does not write frames to disk
    unless you save them yourself.
    """
    video = Path(video_path)
    if not video.exists():
        raise FileNotFoundError(f"Video not found: {video_path}")
    # Build ffmpeg command to output raw frames at the desired FPS
    # The `-vf fps=fps` filter reduces the frame rate; `-vframes` can
    # limit the number of frames extracted.
    args = [
        'ffmpeg', '-i', str(video), '-vf', f'fps={fps}',
        '-f', 'image2pipe', '-pix_fmt', 'rgb24', '-vcodec', 'rawvideo', '-'
    ]
    if max_frames is not None:
        # Prepend -vframes to limit frames; note that ffmpeg expects
        # integer counts.
        args[4:4] = ['-vframes', str(max_frames)]
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    frames: List[Image.Image] = []
    # Compute the width and height of the video using ffprobe
    try:
        probe = ffmpeg.probe(str(video))
        streams = probe.get('streams', [])
        # Choose the first video stream
        vs = next((s for s in streams if s.get('codec_type') == 'video'), None)
        if vs is None:
            raise RuntimeError('No video stream found')
        width = int(vs['width'])
        height = int(vs['height'])
    except ffmpeg.Error as e:
        proc.kill()
        raise RuntimeError(f"ffprobe failed: {e.stderr}") from e

    frame_size = width * height * 3  # RGB24
    count = 0
    while True:
        if max_frames is not None and count >= max_frames:
            break
        raw = proc.stdout.read(frame_size)
        if not raw:
            break
        arr = np.frombuffer(raw, np.uint8).reshape((height, width, 3))
        img = Image.fromarray(arr, 'RGB')
        frames.append(img)
        count += 1
    stderr = proc.stderr.read()
    proc.stdout.close()
    proc.stderr.close()
    proc.wait()
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg returned error code {proc.returncode}: {stderr.decode()}")
    return frames
