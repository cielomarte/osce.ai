"""Scoring utilities for the simplified OSCE pipeline.

This module reads rubric JSON and prompt templates, builds a prompt by
injecting the transcript and optional vision captions, and calls an
LLM (via the OpenAI API) to obtain structured scores.  The LLM is
expected to return a single‑line JSON object containing a total
`score`, a per‑item `scores` dictionary, an `explanation` and a
`trace`.  See the prompt templates under ``medai_osce/prompts`` for
examples.

The default implementation uses the OpenAI chat completion API via
the ``openai`` Python package.  To use it you must set the
``OPENAI_API_KEY`` environment variable.  You can substitute any
other LLM by modifying the ``call_llm`` function.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import openai  # type: ignore


@dataclass
class ScoringResult:
    rubric_title: str
    score: float
    scores: Dict[str, int]
    explanation: str
    trace: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "title": self.rubric_title,
            "score": self.score,
            "scores": self.scores,
            "explanation": self.explanation,
            "trace": self.trace,
        }


def load_rubric(rubric_name: str) -> Dict[str, Any]:
    """Load a rubric JSON by name.

    Parameters
    ----------
    rubric_name:
        The filename stem of the rubric (e.g. ``"communication_engagement_v1"``).

    Returns
    -------
    dict
        The parsed rubric.  Raises ``FileNotFoundError`` if the
        corresponding file does not exist.
    """
    path = Path(__file__).resolve().parent / "rubrics" / f"{rubric_name}.json"
    if not path.exists():
        raise FileNotFoundError(f"Rubric not found: {path}")
    return json.loads(path.read_text())


def load_prompt_template(rubric_name: str) -> str:
    """Load the prompt template associated with a rubric.

    Prompt files are stored under ``medai_osce/prompts`` with the same
    name as the rubric (e.g. ``communication_engagement_v1_prompt.txt``).
    """
    path = Path(__file__).resolve().parent / "prompts" / f"{rubric_name}_prompt.txt"
    if not path.exists():
        raise FileNotFoundError(f"Prompt template not found: {path}")
    return path.read_text()


def build_prompt(template: str, rubric: Dict[str, Any], transcript: str, vision: Optional[str] = None) -> str:
    """Inject transcript, vision and rubric into the prompt template.

    This function replaces the curly‑brace placeholders ``{{transcript}}``,
    ``{{vision}}`` and ``{{rubric}}`` in the template.  If ``vision`` is
    ``None``, the placeholder is replaced with an empty string.
    """
    return (
        template
        .replace("{{transcript}}", transcript.strip())
        .replace("{{vision}}", (vision or "").strip())
        .replace("{{rubric}}", json.dumps(rubric, ensure_ascii=False))
    )


def call_llm(prompt: str, model: str = "gpt-4o", max_tokens: int = 512) -> str:
    """Call the OpenAI chat completion API with a prompt.

    Parameters
    ----------
    prompt:
        The full prompt to send to the LLM.  It must contain both
        system and user messages separated by role tags as required by
        OpenAI.  The prompt templates in this repository include the
        `[ROLE: system]` tag; this function will convert those tags into
        the appropriate message objects.
    model:
        The OpenAI model to use (defaults to ``gpt-4o``).  You can set
        this to ``gpt-3.5-turbo`` or any other supported model.
    max_tokens:
        Maximum number of tokens to generate in the response.  Since
        scoring prompts ask for a single‑line JSON, a small value
        suffices.

    Returns
    -------
    str
        The raw text of the model's response.
    """
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY must be set to call the OpenAI API")
    openai.api_key = api_key
    # Parse the prompt into role‑segmented messages.  The prompt template
    # uses markers like "[ROLE: system]".  We'll split on these markers
    # and construct the chat completion payload.
    messages: List[Dict[str, str]] = []
    current_role: Optional[str] = None
    current_content: List[str] = []
    for line in prompt.splitlines():
        if line.startswith("[ROLE: ") and line.endswith("]"):
            # flush previous
            if current_role is not None:
                messages.append({"role": current_role.lower(), "content": "\n".join(current_content).strip()})
                current_content = []
            current_role = line[len("[ROLE: ") : -1]
        else:
            current_content.append(line)
    # append the last segment
    if current_role is not None:
        messages.append({"role": current_role.lower(), "content": "\n".join(current_content).strip()})
    else:
        # If no role markers, send everything as a single user message
        messages.append({"role": "user", "content": prompt})

    response = openai.ChatCompletion.create(
        model=model,
        messages=messages,
        max_tokens=max_tokens,
        temperature=0.0,
    )
    # Extract the assistant message text
    return response["choices"][0]["message"]["content"]


def parse_llm_response(text: str) -> ScoringResult:
    """Parse the JSON returned by the LLM into a ScoringResult.

    This function strips any leading or trailing code fences or extra
    characters before attempting to decode JSON.  It validates that
    required fields are present and types are as expected.
    """
    cleaned = text.strip()
    # Remove common markdown fences
    if cleaned.startswith("```json"):
        cleaned = cleaned[len("```json"):]
    if cleaned.startswith("```"):
        cleaned = cleaned[len("```"):]
    if cleaned.endswith("```"):
        cleaned = cleaned[:-3]
    # Find the first and last curly braces
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start == -1 or end == -1 or start >= end:
        raise ValueError(f"Could not locate JSON object in LLM response: {text}")
    try:
        payload = json.loads(cleaned[start:end+1])
    except json.JSONDecodeError as exc:
        raise ValueError(f"Failed to parse JSON from LLM response: {cleaned}") from exc
    # Validate payload
    title = payload.get("title")
    score = payload.get("score")
    scores = payload.get("scores")
    explanation = payload.get("explanation")
    trace = payload.get("trace")
    if not isinstance(title, str) or not isinstance(explanation, str) or not isinstance(trace, str):
        raise ValueError(f"Invalid response fields: {payload}")
    if not isinstance(score, (int, float)):
        raise ValueError(f"Score must be numeric: {payload}")
    if not isinstance(scores, dict):
        raise ValueError(f"scores must be a dict: {payload}")
    # Cast per‑item scores to ints
    norm_scores: Dict[str, int] = {}
    for k, v in scores.items():
        norm_scores[str(k)] = int(v)
    return ScoringResult(
        rubric_title=title,
        score=float(score),
        scores=norm_scores,
        explanation=explanation,
        trace=trace,
    )


def score_rubric(
    rubric_name: str,
    transcript: str,
    vision_captions: Optional[List[str]] = None,
    model: str = "gpt-4o",
) -> ScoringResult:
    """Score a transcript against a rubric.

    Parameters
    ----------
    rubric_name:
        Name of the rubric (file stem without extension).
    transcript:
        Full transcript of the encounter.
    vision_captions:
        Optional list of vision captions.  When provided, the list will
        be concatenated with semicolons and inserted into the prompt.
    model:
        Which OpenAI model to use.  Defaults to ``gpt-4o``.

    Returns
    -------
    ScoringResult
        The parsed result containing total and per‑item scores.
    """
    rubric = load_rubric(rubric_name)
    template = load_prompt_template(rubric_name)
    vision_text = "; ".join(vision_captions or [])
    prompt = build_prompt(template, rubric, transcript, vision_text)
    raw = call_llm(prompt, model=model)
    return parse_llm_response(raw)
